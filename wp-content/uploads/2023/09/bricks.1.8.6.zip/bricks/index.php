<?php
get_header();

require locate_template( 'template-parts/content.php' );

get_footer();
